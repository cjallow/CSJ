// 
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// HW_convolve:
//
// Apply image convolution on I1. Output is in I2.
//
void
HW_convolve(ImagePtr I1, ImagePtr Ikernel, ImagePtr I2)
{

	IP_copyImageHeader(I1, I2);
	int w = I1->width();
	int h = I1->height();

    // filter dimensions
	int kernel_w = Ikernel->width();
	int kernel_h = Ikernel->height();

    // create space for kernel height (rows) in circular buffer
	uchar *buff[32], *row[32];
	int kernel_w2 = kernel_w / 2;
	int kernel_h2 = kernel_h / 2;
	for (int i = 0; i < kernel_h; i++) {
		buff[i] = new uchar[w+kernel_w-1];  // scanline buffer
		row[i]  = buff[i] + kernel_w2;      // point to buffer past padding
	}

	int i, j, type;
    ChannelPtr<uchar> p1, p2;
    ChannelPtr<float> p_kernel, wt;

    IP_getChannel(Ikernel, 0, p_kernel, type);

	for (int ch = 0; IP_getChannel(I1, ch, p1, type); ch++) {
        IP_getChannel(I2, ch, p2, type);

		//scanline for row[0]
        for(int x = 0; x < w; x++)     row[0][x]  = *p1++;  // copy row
        for(int x = 1; x <= kernel_w2; x++)  row[0][-x] = row[0][0];  // pad left side
        for(int x = w; x < w+kernel_w2; x++) row[0][x]  = row[0][w-1];  // pad right side
        
        // replicate row[0] to fill upper half of neighborhood
        for(i = 1; i <= kernel_h2; i++) {
            for(j = 0; j < w+kernel_w-1; j++) buff[i][j] = buff[0][j];
        }
        
        // scanline for all other rows into circular buffer
        for(; i < kernel_h; i++) {
            for(int x = 0; x < w; x++)     row[i][x]  = *p1++;  // copy row
            for(int x = 1; x <= kernel_w2; x++)  row[i][-x] = row[i][0];  // pad left side
            for(int x = w; x < w+kernel_w2; x++) row[i][x]  = row[i][w-1];  // pad  right side
        }
        // visit all rows
        int sum;
        for(int y = 0; y < h; y++) {
            for(int x = 0; x < w; x++) {

            	sum = 0;
            	wt = p_kernel;
            	for(i = 0; i < kernel_h; i++) {
            		for(j = -kernel_w2; j <= kernel_w2; j++) {
            			sum += ((int) row[i][x+j] * *wt++);
            		}
            	}
            	*p2++ = CLIP(sum, 0, MaxGray);
            }

            for(i = 0; i < kernel_h-1; i++)  // advance all rows
            	row[i] = row[i+1];
            
            row[i] = buff[y % kernel_h] + kernel_w2; // last row of circular buffer

            if(y < h - kernel_h) {  // copy next scanline into last row of circular buffer
            	for(int x = 0; x < w; x++)     row[i][x]  = *p1++;  // copy row
            	for(int x = 1; x <= kernel_w2; x++)  row[i][-x] = row[i][0];  // pad left side
            	for(int x = w; x < w+kernel_w2; x++) row[i][x]  = row[i][w-1];  // pad  right side
            }
        }
	}
	for(i = 0; i < kernel_h; i++)  // free memory
		delete [] buff[i];
}
