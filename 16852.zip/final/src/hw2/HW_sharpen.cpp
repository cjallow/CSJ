extern void HW_blur  (ImagePtr, int, int, ImagePtr);
extern void blur1D(ChannelPtr<uchar>, int, int, int, ChannelPtr<uchar>);
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// HW_sharpen:
//
// Sharpen image I1. p2put is in I2.
//
void
HW_sharpen(ImagePtr I1, int size, double factor, ImagePtr I2)
{
    IP_copyImageHeader(I1, I2);
    int total = I1->width () * I1->height() ;
    
    HW_blur(I1, size, size, I2); //save blurred to I2
    
    // will range from [-256, 255]
    int lut[MXGRAY * 2];
    for(int i = 0; i < MXGRAY * 2; i++){
        lut[i] = (i - MXGRAY) * factor;
    }
    
    int type;
    ChannelPtr<uchar> p1, p2, endd;
    
    for(int ch = 0; IP_getChannel(I1, ch, p1, type); ch++) {
        IP_getChannel(I2, ch, p2, type);
        for(endd = p1 + total; p1 < endd;){
            *p2 = CLIP(*p1 + lut[(*p1 - *p2) + MXGRAY], 0, MaxGray);  // take the difference of I1 pixel and the blurred image pixel
            p1++;							// add to I1 pixel and clip
            p2++;
        }
    }
}
