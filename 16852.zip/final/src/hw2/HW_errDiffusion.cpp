void gammaCorrect(ImagePtr, double, ImagePtr);

// Written by:  Sammy Ramirez and Christine Mossiah
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// HW_errDiffusion:
//
// Apply error diffusion algorithm to image I1.
//
// This procedure produces a black-and-white dithered version of I1.
// Each pixel is visited and if it + any error that has been diffused to it
// is greater than the threshold, the output pixel is white, otherwise it is black.
// The difference between this new value of the pixel from what it used to be
// (somewhere in between black and white) is diffused to the surrounding pixel
// intensities using different weighting systems.
//
// Use Floyd-Steinberg     weights if method=0.
// Use Jarvis-Judice-Ninke weights if method=1.
//
// Use raster scan (left-to-right) if serpentine=0.
// Use serpentine order (alternating left-to-right and right-to-left) if serpentine=1.
// Serpentine scan prevents errors from always being diffused in the same direction.
//
// A circular buffer is used to pad the edges of the image.
// Since a pixel + its error can exceed the 255 limit of uchar, shorts are used.
//
// Apply gamma correction to I1 prior to error diffusion.
// Output is saved in I2.
//
void
HW_errDiffusion(ImagePtr I1, int method, bool serpentine, double gamma, ImagePtr I2)
{
	IP_copyImageHeader(I1, I2);
	int w = I1->width();
	int h = I1->height();

	// call gamma from point ops
	gammaCorrect(I1, gamma, I2);

	//create buffer 
	short *buf[3];
	buf[0] = new short[w+4];
	buf[1] = new short[w+4];
	buf[2] = new short[w+4];

	// create 3 rows to point to the buffer past the padding of 2
	short *row0 = buf[0] + 2;
	short *row1 = buf[1] + 2;
	short *row2 = buf[2] + 2;

	// weights for both Floyd-Steinberg and Jarvis-Judice-Ninke
	double weight_FS[4], weight_JJN[4];
	weight_FS[0] = 7. / 16.;
	weight_FS[1] = 5. / 16.;
	weight_FS[2] = 3. / 16.;
	weight_FS[3] = 1. / 16.;

	weight_JJN[0] = 7. / 48.;
	weight_JJN[1] = 5. / 48.;
	weight_JJN[2] = 3. / 48.;
	weight_JJN[3] = 1. / 48.;

	int threshold = MaxGray >> 1;

	int type;
    ChannelPtr<uchar> p1, p2, endd, output;
	for (int ch = 0; IP_getChannel(I2, ch, p1, type); ch++) { // use the gamma image called earlier
		IP_getChannel(I2, ch, p2, type);  

		// rows go into circular buffer
		switch(method) {
		case 0:  // Floyd-Steinberg (2 rows)
			//row 0
			for(int x = 0; x < w; x++) row0[x] = *p1++; // copy row
			row0[-1] = row0[0];  // pad left side
			row0[w]  = row0[w-1];  // pad right side

			// row 1
			for(int x = 0; x < w; x++) row1[x] = *p1++;  // copy row
			row1[-1] = row1[0];		// pad left side
			row1[w]  = row1[w-1];	// pad right side
			break;

		case 1: // Jarvis-Judice-Ninke (3 rows) (copy row and pad both side like above)
			// row 0
			for(int x = 0; x < w; x++) row0[x] = *p1++;
			row0[-2] = row0[-1] = row0[0];
			row0[w+1] = row0[w]  = row0[w-1];

			// row 1
			for(int x = 0; x < w; x++) row1[x] = *p1++;
			row1[-2] = row1[-1] = row1[0];
			row1[w+1] = row1[w]  = row1[w-1];

			// row 2
			for(int x = 0; x < w; x++) row2[x] = *p1++;
			row2[-2] = row2[-1] = row2[0];
			row2[w+1] = row2[w]  = row2[w-1];
			break;
		}

		// visit all rows (convolution)
		for(int y = 0; y < h; y++,p2+=w) {
			output = p2; 
			if(!(y%2) || !serpentine) {
				for(int x = 0; x < w; x++){
					// init output
					if(row0[x] < threshold)
						output[x] = 0;
					else output[x] = MaxGray;

					// compute error
					int err = row0[x] - output[x];

					// deposit errors
					switch(method) {
					case 0: // Floyd-Steinberg
						row0[x+1] += err * weight_FS[0];
						row1[x-1] += err * weight_FS[2];
						row1[x]   += err * weight_FS[1];
						row1[x+1] += err * weight_FS[3];
						break;

					case 1: // Floyd-Steinberg
						row0[x-1] += err * weight_JJN[0];
						row0[x+1] += err * weight_JJN[1];
						row1[x-2] += err * weight_JJN[2];
						row1[x-1] += err * weight_JJN[1];
						row1[x]   += err * weight_JJN[0];
						row1[x+1] += err * weight_JJN[1];
						row1[x+2] += err * weight_JJN[2];
						row2[x-2] += err * weight_JJN[3];
						row2[x-1] += err * weight_JJN[2];
						row2[x]   += err * weight_JJN[1];
						row2[x+1] += err * weight_JJN[2];
						row2[x+2] += err * weight_JJN[3];
						break;
					}
				}
			} else {  //visit all rows backwards  (this is the serpentine feature)
				for(int x = w-1; x >= 0; x--) {
					// init outputput
					if(row0[x] < threshold)
						output[x] = 0;
					else output[x] = MaxGray;

					// compute error
					int err = row0[x] - output[x];

					// deposit errors
					switch(method) {
					case 0: // Floyd-Steinberg
						row0[x-1] += err * weight_FS[0];
						row1[x+1] += err * weight_FS[2];
						row1[x]   += err * weight_FS[1];
						row1[x-1] += err * weight_FS[3];

					case 1: //// Floyd-Steinberg
						row0[x+1] += err * weight_JJN[0];
						row0[x-1] += err * weight_JJN[1];
						row1[x+2] += err * weight_JJN[2];
						row1[x+1] += err * weight_JJN[1];
						row1[x]   += err * weight_JJN[0];
						row1[x-1] += err * weight_JJN[1];
						row1[x-2] += err * weight_JJN[2];
						row2[x+2] += err * weight_JJN[3];
						row2[x+1] += err * weight_JJN[2];
						row2[x]   += err * weight_JJN[1];
						row2[x-1] += err * weight_JJN[2];
						row2[x-2] += err * weight_JJN[3];
						break;
					}
				}
			}

			// advance rows
			switch(method) {
			case 0: // Floyd-Steinberg
					row0 = row1;  // advance row0 to row1
					row1 = buf[y%2] + 2;  // advance row 1 passed padding
					if(y < h - 2) {
						for(int x = 0; x < w; x++)  // copy into row
							row1[x] = *p1++;
					}
					break;

			case 1:  // Floyd-Steinberg
					row0 = row1;  // advance row0 to row1
					row1 = row2;  // advance row1 to row2
					row2 = buf[y%3] + 2;  // advance row2 passed padding
					if(y < h - 3) {
						for(int x = 0; x < w; x++)
							row2[x] = *p1++;
					}
					break;
			}			
		}
	}

			// free memory
			delete [] buf[0];
			delete [] buf[1];
			delete [] buf[2];		
}
  

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// gammaCorrect:
//
// Apply gamma correction to image I1.
// Save result in I2.
//
void
gammaCorrect(ImagePtr I1, double gamma, ImagePtr I2)
{
	IP_copyImageHeader(I1, I2);
	int w = I1->width();
	int h = I1->height();
	int total = w * h;

    // init gamma
    gamma = 1.00/gamma;

    int i, lut[MXGRAY];
    for (i = 0; i < MXGRAY; i++) {
		lut[i] = (int) (MaxGray * pow (((double)i / MaxGray), gamma));
	}	
	

	int type;
	ChannelPtr<uchar> p1, p2, endd;
	for (int ch = 0; IP_getChannel(I1, ch, p1, type); ch++) {
		IP_getChannel(I2, ch, p2, type);
		for (endd = p1 + total; p1<endd;) *p2++ = lut[*p1++];
	}
}
