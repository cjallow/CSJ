void blur1D(ChannelPtr<uchar>, int, int, int, ChannelPtr<uchar>);

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// HW_blur:
//
// Blur image I1 with a box filter (unweighted averaging).
// The filter has width filterW and height filterH.
// We force the kernel dimensions to be odd.
// Output is in I2.
//
void
HW_blur(ImagePtr I1, int filterW, int filterH, ImagePtr I2) {
    IP_copyImageHeader(I1, I2);
    int w = I1->width();
    int h = I1->height();

    
    // filters are only odd (failsafe in case it is even)
    if ((filterW % 2) == 0) {
        filterW++;
    }    
    if ((filterH % 2) == 0) {
        filterH++;
    }
    
    int type;
    ChannelPtr<uchar> src, dst;
    

    for (int ch = 0; IP_getChannel(I1, ch, src, type); ch++) {
        IP_getChannel(I2, ch, dst, type);
        if (filterW > 1){
            // start with the rows 
            for (int row = 0; row < h; row++) {  // This is the 1st pass
                blur1D(src, w, 1, filterW, dst);
                src += w;
                dst += w;
            }
            
            IP_getChannel(I2, ch, src, type);  // new input
        }
        else
            IP_copyImage(I1,I2);  // simply copying I1 to I2
         
        if (filterH > 1) {
            IP_getChannel(I2, ch, dst, type);
            
            //then go through the columns
            for (int x = 0; x < w; x++) {      //  This is the 2nd pass
                blur1D(src, h, w, filterH, dst);
                src += 1;
                dst += 1;
            }
        }
    }
}



// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// blur1D:
//
// Blur src with 1D box filter of width ww.
//
void
blur1D(ChannelPtr<uchar> src, int len, int stride, int ww, ChannelPtr<uchar> dst) {
    
    uchar* buffer = new uchar[len+ww-1];  // scanline buffer

    int padLen = ww/2;
    uchar *p;
    p = buffer + padLen;  // past the padding
    for(int i = 0; i < len; i++) {   // copy into buffer
        p[i] = src[i*stride];   
    }
    
    uchar *p1, *p2;
    
    //begining of the padding
    p1 = buffer;
    
    //end size of padding
    p2 = buffer + len + padLen;
     
    //start the padding
    for (int j = 0; j < padLen; j++) {
        p1[j] = p[0]; // pad left side
        p2[j] = p[len - 1];  // pad right side
    }
    
    // init the sum
    int k;
    int sumA = 0;
    for (k = 0; k < ww - 1; k++)
        sumA += buffer[k];
    
    // compute the output along the scanline
    for (int x = 0; x < len; x++) {
        sumA += buffer[k++];
        dst[x * stride] = sumA/ww;
        sumA -= buffer[k - ww];
    }
    // free memory
    delete [] buffer;
    
}
